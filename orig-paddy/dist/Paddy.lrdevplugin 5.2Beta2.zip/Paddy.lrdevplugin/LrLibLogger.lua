LrLibLogger = {}

-- Create the logger and enable the print function
local LrLogger = import 'LrLogger'
local myLogger = LrLogger('libraryLogger')
myLogger:enable("print") -- Pass either a string or a table of actions

-- Write trace information to the logger
function LrLibLogger.outputToLog(message)
	myLogger:trace(message)
end
