
require 'LrLibLogger.lua'

LrLibUtils = {}

function LrLibUtils.addSlashToEnd (str)
	local len = str:len()
	local lastchar = str:sub(len)

	if lastchar ~= "/" then
		str = str.."/"
	end

	return str
end

function LrLibUtils.addhttp (str)
	local len = str:len()
	local http = "http://"
	local first = str:sub(http)

	if first ~= http then
		str = http..str
	end

	return str
end

function LrLibUtils.trim(s)
  -- from PiL2 20.4
  return (s:gsub("^%s*(.-)%s*$", "%1"))
end
