local app = import 'LrApplication'
local LrFunctionContext = import 'LrFunctionContext'
local LrHttp = import "LrHttp"
local LrFtp = import 'LrFtp'
local LrDate = import 'LrDate'
local prefs = import 'LrPrefs'.prefsForPlugin()
local LrDialogs = import 'LrDialogs'
local LrXml = import 'LrXml'
local LrErrors = import 'LrErrors'
local LrPathUtils = import 'LrPathUtils'
local LrTasks = import 'LrTasks'
local catalog = app.activeCatalog()

require 'LrLibLogger.lua'
require 'LrLibUtils.lua'

PaddyAPI = {}

local APIversion = 0.997

local paddyfolderpath = LrPathUtils.child(_PLUGIN.path, "paddy")
local paddycmdlinepath = LrPathUtils.child( paddyfolderpath, "ap.exe")


function PaddyAPI.Start ()
    if _PLUGIN.enabled then
      LrLibLogger.outputToLog("Starting Paddy")
      PaddyAPI.SendCommand ("Start")
      LrLibLogger.outputToLog("Paddy Started")
   end
end


function PaddyAPI.ReStart ()
	LrLibLogger.outputToLog("restarting Paddy")
	PaddyAPI.SendCommand ("ReStartPaddy")
	LrLibLogger.outputToLog("Paddy Restarted")
end

function PaddyAPI.ShowSplash ()
	PaddyAPI.SendCommand ("ShowSplashScreen")
end


function PaddyAPI.MenuKeyboardMouseMidi ()
	LrLibLogger.outputToLog("Opening Keyboard Setup Menu")
	PaddyAPI.SendCommand ("KeyboardMouseMidi")
end
function PaddyAPI.MenuPresetMacro ()
	LrLibLogger.outputToLog("Opening Preset and Macro Setup Menu")
	PaddyAPI.SendCommand ("PresetMacro")
end
function PaddyAPI.MenuImportExport ()
	LrLibLogger.outputToLog("Opening Import and Export Setup Menu")
	PaddyAPI.SendCommand ("ImportExport")
end
function PaddyAPI.MenuGeneralSetup ()
	LrLibLogger.outputToLog("Opening General Setup Menu")
	PaddyAPI.SendCommand ("GeneralSetup")
end


function PaddyAPI.MenuBasicSetup ()
	LrLibLogger.outputToLog("Opening Basic Setup Menu")
	PaddyAPI.SendCommand ("BasicSetup")
end

function PaddyAPI.MenuDefineGeneric ()
	PaddyAPI.SendCommand ("DefineGeneric")
end

function PaddyAPI.MenuMapGeneric ()
	PaddyAPI.SendCommand ("MapGeneric")
end

function PaddyAPI.MenuSliderDelta ()
	PaddyAPI.SendCommand ("SliderDelta")
end

function PaddyAPI.MenuLocalAdjustment ()
	PaddyAPI.SendCommand ("Adjustment")
end

function PaddyAPI.MenuRelativePresets ()
	PaddyAPI.SendCommand ("Relative")
end

function PaddyAPI.MenuCameraProfiles ()
	PaddyAPI.SendCommand ("CameraProfiles")
end

function PaddyAPI.MenuMacros ()
	PaddyAPI.SendCommand ("PaddyMacros")
end

function PaddyAPI.MenuScriptEdit ()
	PaddyAPI.SendCommand ("ScriptEdit")
end

function PaddyAPI.MenuPlayScript ()
	PaddyAPI.SendCommand ("PlayScript")
end

function PaddyAPI.MenuScriptRecord ()
	PaddyAPI.SendCommand ("ScriptRecord")
end

function PaddyAPI.MenuScriptStop ()
	PaddyAPI.SendCommand ("ScriptEndRecord")
end

function PaddyAPI.MenuMouse ()
	LrLibLogger.outputToLog("Opening Mouse Menu")
	PaddyAPI.SendCommand ("AssignMouseAndWheel")
end

function PaddyAPI.MenuMidiSliders ()
	LrLibLogger.outputToLog("Opening MidiSliders Menu")
	PaddyAPI.SendCommand ("AssignMidiSliders ")
end

function PaddyAPI.MenuKeyboard ()
	LrLibLogger.outputToLog("Opening Keyboard Menu")
	PaddyAPI.SendCommand ("AssignKeyboard")
end

function PaddyAPI.MenuLocalAdjustmentPresets ()
	LrLibLogger.outputToLog("Opening Local Adjustment Presets Menu")
	PaddyAPI.SendCommand ("Adjustment")
end

function PaddyAPI.Close ()
	LrLibLogger.outputToLog("Closing Paddy")
	PaddyAPI.SendCommand ("ExitPaddy")
end

function PaddyAPI.SendCommand (command)
	-- Close Paddy
	LrTasks.startAsyncTask( function ()
		local Paddycmdline
		Paddycmdline = paddycmdlinepath -- .." "..command
		LrLibLogger.outputToLog(PaddyPath)

		-- local commandLine = string.format ('%s "%s"', WIN_ENV and "cmd /c" or "sh ", Paddycmdline)
		local commandLine = string.format ('"%s"', Paddycmdline)
		commandLine = commandLine.." "..command
		LrLibLogger.outputToLog(commandLine)
		LrTasks.execute (commandLine)

	end )
end

function PaddyAPI.SendCommandold (command)
	-- Close Paddy
	LrTasks.startAsyncTask( function ()
		local Paddycmdline
		Paddycmdline = paddycmdlinepath.." "..command
		LrLibLogger.outputToLog(PaddyPath)

		local commandLine = string.format ('%s "%s"', WIN_ENV and "cmd /c" or "sh ", Paddycmdline)
		LrLibLogger.outputToLog(commandLine)
		local exitstatus
		exitstatus = LrTasks.execute (commandLine)
		LrLibLogger.outputToLog(exitstatus)

	end )
end

--~ function PaddyAPI.Startold ()
--~ 	LrLibLogger.outputToLog("Starting Paddy")
--~ 	-- Start Paddy
--~ 	LrTasks.startAsyncTask( function ()
--~ 		local PaddyPath = LrPathUtils.child( _PLUGIN.path, "PaddyStart.bat")
--~ 		LrLibLogger.outputToLog(PaddyPath)
--~
--~ 		local commandLine = string.format ('%s "%s"', WIN_ENV and "cmd /c" or "sh ", PaddyPath)
--~ 		LrLibLogger.outputToLog(commandLine)
--~ 		LrTasks.execute (commandLine)
--~
--~ 	end )

--~ end
