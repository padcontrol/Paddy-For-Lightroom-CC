require 'PaddyAPI.lua'

PaddyAPI.ShowSplash ()
