require 'PaddyAPI.lua'

PaddyAPI.MenuPlayScript ()
