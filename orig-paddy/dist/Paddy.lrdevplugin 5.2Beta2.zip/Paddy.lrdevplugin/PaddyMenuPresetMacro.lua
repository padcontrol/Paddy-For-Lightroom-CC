require 'PaddyAPI.lua'

PaddyAPI.MenuPresetMacro ()
