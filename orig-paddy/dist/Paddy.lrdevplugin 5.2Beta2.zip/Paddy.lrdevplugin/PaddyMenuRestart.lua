require 'LrLibLogger.lua'
require 'LrLibUtils.lua'
require 'PaddyAPI.lua'

LrLibLogger.outputToLog("restarting Paddy")
PaddyAPI.ReStart ()