require 'PaddyAPI.lua'

PaddyAPI.MenuScriptRecord ()
