require 'PaddyAPI.lua'

PaddyAPI.MenuScriptStop ()
