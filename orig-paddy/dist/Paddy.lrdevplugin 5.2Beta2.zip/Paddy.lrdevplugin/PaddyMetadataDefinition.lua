return {

	metadataFieldsForPhotos = {
		{
			id = 'Paddy',
			version=1.0,
			-- hidden value
		},		
	},
	
	schemaVersion = 1.0,
}