
require 'PaddyPluginManager'

return{
	sectionsForTopOfDialog = PaddyPluginManager.sectionsForTopOfDialog,

}