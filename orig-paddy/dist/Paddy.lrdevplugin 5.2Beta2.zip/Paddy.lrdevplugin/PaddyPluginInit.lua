_G.pluginID="com.allengambrell.paddy"
_G.Name="Paddy for Lightroom"
_G.Version=1.0
_G.URL = "http://sites.google.com/site/dorfl68/"
_G.PluginURL = "http://sites.google.com/site/dorfl68/"
_G.Descript = ""

require 'LrLibLogger.lua'
require 'LrLibUtils.lua'
require 'PaddyAPI.lua'

-- Auto Start Paddy
LrLibLogger.outputToLog("Starting Paddy")
PaddyAPI.Start ()