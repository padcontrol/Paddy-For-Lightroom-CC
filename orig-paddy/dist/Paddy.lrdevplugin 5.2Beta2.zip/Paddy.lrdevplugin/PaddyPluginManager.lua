
local LrView = import "LrView"
local LrHttp = import "LrHttp"
local bind = import "LrBinding"
local app = import 'LrApplication'
local LrLogger = import 'LrLogger'
local LrFunctionContext = import 'LrFunctionContext'
local prefs = import 'LrPrefs'.prefsForPlugin()

PaddyPluginManager = {}

require 'LrLibLogger.lua'
require 'LrLibUtils.lua'
require 'PaddyAPI.lua'

function PaddyPluginManager.sectionsForTopOfDialog(f, p)

	
	return {
			-- section for the top of the dialog			
			{
				title = _G.Name,
				spacing = f:control_spacing(),				
--~ 				f:row {
--~ 					f:picture {
--~ 						value =  _PLUGIN:resourceId("image.png"),
--~ 					},
--~ 				},
				f:column {
					f:static_text { 
						title = "Paddy for Lightroom by Dorfl68 (with thanks to Allen Gambrell)\n\n",
						width = 350,
						height_in_lines= -1,
						alignment = 'left',
						font = "<system/small>",
					},
					
				},
			},
			{
				title = "Paddy Information",
				spacing = f:control_spacing(),
				f:column {
					f:static_text {
						title = 'Paddy for Lightroom by dorfl68',
						--font = props.selectedgaltext,
						--width = props.selectedgalitemwidth,
						mouse_down = function()
							LrHttp.openUrlInBrowser(LrPluginInfoUrl)
						end,
						text_color = import 'LrColor'( 0, 0, 1 ),
					},
					
				},				
			},
			{
				title = "Start and Close Paddy",
				spacing = f:control_spacing(),
				
				f:row {
					f:push_button {
						width = 150,
						title = 'Start Paddy',
						enabled = true,
						action = function()
							LrLibLogger.outputToLog("Starting Paddy")
							PaddyAPI.Start ()
						end,
					},
					f:push_button {
						width = 150,
						title = 'Close Paddy',
						enabled = true,
						action = function()
							LrLibLogger.outputToLog("Closing Paddy")
							PaddyAPI.Close ()
						end,
					},
				},				
			},
		}
end
