require 'LrLibLogger.lua'
require 'LrLibUtils.lua'
require 'PaddyAPI.lua'

-- Auto Start Paddy
LrLibLogger.outputToLog("Closing Paddy")
PaddyAPI.Close()