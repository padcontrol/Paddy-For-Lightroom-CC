--[[----------------------------------------------------------------------------
Paddy for Lightroom
	Lightroom Plugin by Allen Gambrell    www.allengambrell.com
	Paddy by dorfl68 www.paddy-for-lightroom.com

------------------------------------------------------------------------------]]

return {
	VERSION = { major=1, minor=0, revision=11020, build=0, },
	LrSdkVersion = 3.0,
	LrSdkMinimumVersion = 3.0, -- minimum SDK version required by this plug-in

	LrToolkitIdentifier = 'com.allengambrell.paddy',
	LrPluginName = "Paddy for Lightroom",
	LrPluginInfoUrl = "www.paddy-for-lightroom.com",

 	LrInitPlugin = 'PaddyPluginInit.lua', -- Load Paddy when plugin is loaded
	LrShutdownPlugin = 'PaddyPluginShutDown.lua', --closes paddy when the plugin is reloaded
	LrDisablePlugin = 'PaddyPluginShutDown.lua', --closes paddy when the plugin is disabled

	-- Add the entry for the Plug-in Manager Dialog
	LrPluginInfoProvider = 'PaddyPluginInfoProvider.lua',

	-- Add the Metadata Definition File
	LrMetadataProvider = 'PaddyMetadataDefinition.lua',

	--~ 	-- Add the menu item the Library menu
	

	LrExportMenuItems = {
		{
			title = "Assign",
			file = "PaddyMenuKeyboardMouseMidi.lua",
		},
		{
			title = "Preset and Macro",
			file = "PaddyMenuPresetMacro.lua",
		},
		{
			title = "Import/Export",
			file = "PaddyMenuImportExport.lua",
		},
		{
			title = "Preferences",
			file = "PaddyMenuGeneralSetup.lua",
		},
		{
			title = "----------------------",
			file = "PaddyMenuSpacer.lua",
		},
		{
			title = "Play a Script",
			file = "PaddyMenuPlayScript.lua",
		},
		{
			title = "Start Recording",
			file = "PaddyMenuScriptRecord.lua",
		},
		{
			title = "Stop Recording",
			file = "PaddyMenuScriptStop.lua",
		},
		{
			title = "Edit Script",
			file = "PaddyMenuScriptEdit.lua",
		},
		{
			title = "----------------------",
			file = "PaddyMenuSpacer.lua",
		},
		{
			title = "Restart",
			file = "PaddyMenuReStart.lua",
		},
		{
			title = "About Paddy",
			file = "PaddyMenuAbout.lua",
		},
		
	},

	LrHelpMenuItems = {
			title = "About Paddy",
			file = "PaddyMenuAbout.lua",
		},

}


